   <?php  $base_url = "http://localhost/cis"; ?>
   <link type="text/css" rel="stylesheet" href="<?= $base_url; ?>/css/bootstrap.min.css" media="all">
   <link type="text/css" rel="stylesheet" href="<?= $base_url; ?>/css/plugins/metisMenu/metisMenu.min.css" media="all">
   <link type="text/css" rel="stylesheet" href="<?= $base_url; ?>/css/plugins/dataTables.bootstrap.css" media="all">
   <link type="text/css" rel="stylesheet" href="<?= $base_url; ?>/css/sb-admin-2.css" media="all">
   <link type="text/css" rel="stylesheet" href="<?= $base_url ?>/css/font-awesome-4.1.0/css/font-awesome.min.css" media="all">
   <script type="text/javascript" src="<?= $base_url; ?>/js/jquery-1.11.0.js"></script>
   <script type="text/javascript" src="<?= $base_url; ?>/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="<?= $base_url; ?>/js/plugins/metisMenu/metisMenu.min.js"></script>
   <script type="text/javascript" src="<?= $base_url; ?>/js/plugins/dataTables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?= $base_url; ?>/js/plugins/dataTables/dataTables.bootstrap.js"></script>
   <script type="text/javascript" src="<?= $base_url; ?>/js/sb-admin-2.js"></script> 
   
 